insert into Person (FIRSTNAME, LASTNAME) values ('Jack', 'Dawson');
insert into Person (FIRSTNAME, LASTNAME) values ('Rose', 'DeWitt');
insert into Person (FIRSTNAME, LASTNAME) values ('Caledon', 'Hockley');
