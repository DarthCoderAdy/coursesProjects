import java.time.LocalDateTime

// TODO Take the date into account, and adjust for inflation
BigDecimal convert(BigDecimal amount, String currencyFrom, LocalDateTime localDateTime, String currencyTo) {
    return amount
}