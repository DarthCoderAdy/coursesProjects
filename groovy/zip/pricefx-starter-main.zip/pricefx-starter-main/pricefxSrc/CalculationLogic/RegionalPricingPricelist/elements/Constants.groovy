import groovy.transform.Field

@Field final String INPUT_FIELD_REGION = "Region"