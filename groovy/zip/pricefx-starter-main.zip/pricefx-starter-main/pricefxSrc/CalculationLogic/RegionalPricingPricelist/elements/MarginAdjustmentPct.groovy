return api.vLookup(
        'MarginAdjustment',
        api.product('ProductGroup')
)