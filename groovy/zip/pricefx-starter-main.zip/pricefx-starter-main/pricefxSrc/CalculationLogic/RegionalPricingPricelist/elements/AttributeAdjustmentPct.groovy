return api.vLookup(
        'AttributeAdjustment',
        'AttributeAdjustment',
        [ProductLifeCycle: api.product('ProductLifeCycle')]
)
