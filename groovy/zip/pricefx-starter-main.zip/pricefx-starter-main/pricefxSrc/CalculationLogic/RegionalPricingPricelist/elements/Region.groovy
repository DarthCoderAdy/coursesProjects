return input[Constants.INPUT_FIELD_REGION]
