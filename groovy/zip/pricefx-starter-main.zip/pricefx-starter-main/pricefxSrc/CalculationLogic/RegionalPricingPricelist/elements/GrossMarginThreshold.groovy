return api.vLookup(
        "PriceStrategy",
        "RedAlert",
        [BusinessUnit: api.product("BusinessUnit")]
)