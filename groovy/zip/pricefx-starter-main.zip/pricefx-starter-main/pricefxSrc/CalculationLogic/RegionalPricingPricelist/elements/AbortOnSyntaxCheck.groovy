if (api.syntaxCheck) {
    api.abortCalculation()
}